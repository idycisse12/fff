/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import javafx.scene.paint.Color;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.service;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class IncriptionController implements Initializable {

    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtPassword;
    @FXML
    private TextField txtPrenom;
    @FXML
    private TextField txtLogin;
    @FXML
    private Text txtError;
    @FXML
    private FontAwesomeIcon txtWarning;
    ObservableList<String> patient = FXCollections.observableArrayList();
    @FXML
    private Text txtCon;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        txtWarning.setVisible(false);
        
    }    


    @FXML
    private void handleSignUp(ActionEvent event) throws IOException {
        String nom=txtNom.getText().trim();
        String prenom=txtPrenom.getText().trim();
        String login=txtLogin.getText().trim();
        String password=txtPassword.getText().trim();
        txtError.setVisible(false);
        if(nom.isEmpty()||prenom.isEmpty()||login.isEmpty()||password.isEmpty()){
            txtError.setText("Veuillez remplir les champs vides!!!");
            txtError.setVisible(true);
            txtWarning.setVisible(true);
        }
        else{
         
            this.txtError.getScene().getWindow().hide();
             this.txtWarning.getScene().getWindow().hide();
            AnchorPane root = null;
                        int id_patient = service.addPatient;
        Alert alert = new Alert(AlertType.INFORMATION);
        // Add custom Image to Dialog's title bar
        final Image APPLICATION_ICON = new Image("/images/icons8_XING_100px.png");
        Stage dialogStage = (Stage) alert.getDialogPane().getScene().getWindow();
        dialogStage.getIcons().add(APPLICATION_ICON);
            alert.setTitle("Inscription");
            alert.setContentText("Inscription réussie ");
            alert.setGraphic(root);
            alert.show();
             /* try {
                  
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/v_home.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
              
                 
                 //stage.setPadding(new Insets(10));
                  stage.showAndWait();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }*/
          }
        }
         
        
        
    
    public void clearField(){
    txtNom.clear();
    txtPrenom.clear();
    txtLogin.clear();
    txtPassword.clear();
    }
    @FXML
    private void handleReset(ActionEvent event) {
        clearField();
         this.txtError.setVisible(false);
         this.txtWarning.setVisible(false);
        
    }

    private void handleConnect(MouseEvent event) throws IOException {
         AnchorPane root = null;
        try {
                  
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/v_home.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
              
                 
                 //stage.setPadding(new Insets(10));
                  stage.showAndWait();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

    
}
