/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.PatientDao;
import dao.UserDao;
import entities.DossierMedical;
import entities.Inscription;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.util.List;


/**
 *
 * @author Mr Mouhamed Niang
 */
public class service implements Iservice {

    public static int addPatient;
     UserDao daoUser=new UserDao();
     PatientDao daoPatient=new PatientDao();
    @Override
    public User login(String login,String password) {
       return daoUser.findUserLoginAndPassword(login,password);
    
    }

  
    @Override
    public boolean findByIdPatient(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean searchPatientById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Patient askRendezVous(String libelle, String date) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> showAllRendezVous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> showRendezVousByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean searchDossierMedicalPatientById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> showRendezVousByLibelleAndDate(String libelle, String date) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int showDetailsConsultationById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

        public int addPatient(Patient pat,DossierMedical docM) {
        if(pat.getId()==0){
            int id_patient=daoPatient.insert(pat);
        }
          Inscription ins = new Inscription(pat,docM);
       
         return pat.getId();
    }

    @Override
    public int addPatient(Patient patient) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
