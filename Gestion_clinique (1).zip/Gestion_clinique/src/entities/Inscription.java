/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author MOUHAMED NIANG
 */
public class Inscription {
    private int id;
    private Patient pat;
    private DossierMedical docM;

    public Inscription() {
    }

    public Inscription(int id, Patient pat, DossierMedical docM) {
        this.id = id;
        this.pat = pat;
        this.docM = docM;
    }

    public Inscription(Patient pat, DossierMedical docM) {
        this.pat = pat;
        this.docM = docM;
    }

    public int getId() {
        return id;
    }

    public Patient getPat() {
        return pat;
    }

    public DossierMedical getDocM() {
        return docM;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPat(Patient pat) {
        this.pat = pat;
    }

    public void setDoc(DossierMedical docM) {
        this.docM = docM;
    }
    
    
}
