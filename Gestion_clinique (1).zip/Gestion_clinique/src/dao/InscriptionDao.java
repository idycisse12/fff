/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.IDao;
import entities.Inscription;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MOUHAMED NIANG
 */
public class InscriptionDao implements IDao<Inscription> {
        private final String SQL_INSERT=" INSERT INTO `user"
                + "`(`id`, `nom`, `prenom`, `login`, `password`, `role`, `statut`)"
                + "+VALUES (?,?,?,?,?,ROLE_PATIENT,Null)";
               private DataBase dataBase=new DataBase();
    @Override
    public int insert(Inscription inscription) {
          int idInscription = 0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setInt(1, inscription.getPat().getId());
            dataBase.getPs().setString(2, inscription.getPat().getNom());
            dataBase.getPs().setString(3, inscription.getPat().getPrenom());
            dataBase.getPs().setString(4, inscription.getPat().getLogin());
            dataBase.getPs().setString(5, inscription.getPat().getPassword());       
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                idInscription = rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(InscriptionDao.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            dataBase.closeConnexion();
        }
        return idInscription;
    }
      
    @Override
    public int update(Inscription ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Inscription> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Inscription findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   

    
}
