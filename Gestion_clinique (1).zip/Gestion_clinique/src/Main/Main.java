/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import javafx.scene.layout.StackPane;
public class Main extends Application {
@Override
   public void start(Stage stage) throws Exception  {
    Parent root = FXMLLoader.load(getClass().getResource("/view/v_connexion.fxml"));
    Scene scene = new Scene(root,849,600);
    stage.setScene(scene);
    stage.centerOnScreen();
    //ajouter titre a la fênetre
    stage.setTitle("Clinique 221");

    //ajouter icon
    stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
    stage.show();
    
}

/**
 * @param args the command line arguments
 */
public static void main(String[] args) {
    launch(args);
}

}
